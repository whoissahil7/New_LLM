# Faithfulness-Aware Reranking for Domain-Specific Retrieval-Augmented Generation: An Implementation and Pilot Evaluation on Scientific Claim Verification

**[AUTHOR NAME(S) — TO BE COMPLETED]**
**[AUTHOR AFFILIATION(S) — TO BE COMPLETED]**

---

## Abstract

Two-stage retrieval-augmented generation (RAG) pipelines rerank candidate evidence by topical relevance, but relevance and evidential trustworthiness are not the same property: a passage can be highly relevant to a query while being contradicted elsewhere in the corpus, incomplete, or otherwise unsuited to ground an answer. This paper implements and empirically evaluates a faithfulness-aware reranking architecture that inserts an explicit evidential-adequacy score between relevance reranking and context selection, fusing it with the relevance score before the top-N passages are sent to a generator. Three controlled system configurations are implemented as a single parameterized pipeline — retrieval-only (S1), retrieval with relevance reranking (S2), and retrieval with relevance-plus-faithfulness reranking (S3) — and evaluated on the SciFact scientific-claim-verification benchmark. A retrieval-sufficiency gate (recall@50) is validated on the full development split before any reranking comparison is drawn. A pilot evaluation on 20 test claims shows faithfulness and hallucination-rate metrics moving in the hypothesized direction from S1 to S3, but none of the paired significance tests survive Holm–Bonferroni correction at this sample size, and the faithfulness-scoring stage roughly doubles per-query latency. Hyperparameter tuning and the ablation study specified by the architecture were not executed in this work and are reported as not available rather than estimated. The paper presents the implementation, the pilot findings with their statistical limitations stated explicitly, and the specific next steps required before the hypothesis can be evaluated with adequate power.

**Keywords** — Retrieval-Augmented Generation, Reranking, Faithfulness, Hallucination Mitigation, Natural Language Inference, Information Retrieval, Claim Verification

---

## I. Introduction

### A. Problem Motivation

Retrieval-augmented generation systems ground language-model output in retrieved evidence, and production pipelines increasingly use a two-stage retrieve-then-rerank design: a bi-encoder retrieves a broad candidate set for recall, and a cross-encoder reranks that set for precision. This design improves topical relevance ordering, but the reranker is trained on relevance labels, and relevance is not the same question as trustworthiness. A passage can be topically correct while being contradicted by other evidence, missing a qualifying condition, or otherwise unsuited to ground an answer, and a relevance-only reranker has no mechanism to distinguish that case from a genuinely supportive one. When such a passage reaches the generator, the model does not reliably abstain — it tends to produce a fluent, well-cited, and incorrect answer, since fluency and citation form are largely independent of whether the cited evidence actually supports the claim.

### B. Research Gap

Reranking is now a standard component of production RAG, so demonstrating that reranking helps would not be a novel finding. Existing work on RAG faithfulness has largely evaluated generated answers after the fact — checking whether a completed answer is supported by its context — rather than scoring evidence for its expected supportiveness before generation, at the point where evidence selection is still reversible. A reranking stage that scores candidates on evidential adequacy, independent of and complementary to relevance, addresses this gap directly by acting before generation rather than auditing after it.

### C. Research Objectives and Research Question

The objective of this work is to implement and empirically test such a faithfulness-aware reranking stage, following an architecture specification [17] that defines the fused ranking score

  S(c) = α·Rel(c) + β·Faith(c),  α + β = 1,

with Faith(c) computed from four sub-signals (entailment, self-containment, corpus agreement, source reliability). The research question, unchanged from the specification, is:

*In a domain-specific RAG pipeline, does augmenting a standard cross-encoder reranker with an explicit faithfulness signal measurably improve groundedness and reduce hallucination rate relative to relevance-only reranking, and at what cost in latency and precision?*

### D. Contributions

This paper contributes: (1) a complete, controlled three-system implementation (S1/S2/S3) sharing a single code path, so that the only varying component between configurations is the reranking/faithfulness stage; (2) an instantiation of the architecture on SciFact, including an explicit, non-fabricated resolution of the source-reliability sub-signal, which the target corpus cannot support due to missing metadata; (3) a retrieval-sufficiency gate check confirming that the reranking comparison is methodologically valid; (4) a pilot evaluation reporting the direction of the effect, its statistical significance (or lack thereof) under correction for multiple comparisons, per-stage latency, and abstention behavior; and (5) an explicit account of what remains to be done — hyperparameter tuning and the ablation study — before the central hypothesis can be evaluated with adequate statistical power.

---

## II. Related Work

**Retrieval-augmented generation.** RAG conditions a generator on retrieved evidence rather than relying solely on parametric knowledge [1]; [2] surveys the resulting family of architectures. **Dense and sparse retrieval.** Dense passage retrieval [3] and sentence-embedding models [5] provide the bi-encoder half of the standard two-stage design; BM25 [6] remains a strong sparse baseline, and combining dense and sparse rankings via Reciprocal Rank Fusion [7] is a common way to hybridize them without training a fusion model. **Relevance reranking.** Cross-encoder rerankers that jointly encode the query and each candidate [4] are the standard second stage; benchmarks such as BEIR [8] evaluate retrieval and reranking across heterogeneous domains, including SciFact. **Context utilization.** [9] documents that language models do not use long contexts uniformly, motivating context-ordering strategies that place the strongest evidence at the beginning and end of the context window rather than assuming order does not matter. **Hallucination and factual consistency.** [10] surveys hallucination in natural language generation; [11], [12], and [13] propose model-based factual-consistency scoring, applied to a generated output against its source. **RAG evaluation.** [14] proposes reference-free metrics for RAG pipelines, again evaluating the generated answer rather than the pre-generation evidence set.

**Research gap addressed.** The works above either rerank by relevance alone or assess factual consistency of an already-generated answer. The gap this paper's implementation addresses is a reranking-time signal — computed on candidate evidence before an answer exists — that is fused with relevance rather than substituting for it, and evaluated through its downstream effect on generation rather than only on ranking metrics.

---

## III. System Design and Architecture

### A. Overall Architecture and Data Flow

The pipeline follows the specification in [17]. A query is embedded and used for hybrid retrieval; the resulting top-K candidates are, depending on the system configuration, reranked by relevance, scored for faithfulness, fused, and reduced to a top-N context block, which is passed to the generator along with a fixed grounded-answer prompt. One code path implements all three systems by branching only at the reranking/faithfulness stage:

- **S1 (baseline):** retrieval → context selection → generation. No reranking, no faithfulness scoring.
- **S2 (relevance reranking):** retrieval → cross-encoder rerank → context selection → generation. Equivalent to the fused score with β = 0.
- **S3 (proposed system):** retrieval → cross-encoder rerank → faithfulness scoring → score fusion and gate → context selection → generation.

*[Fig. 1 — end-to-end data-flow diagram, adapted from the source architecture specification (Khan, 2026) [17]; to be inserted in final layout.]*

### B. Retrieval Component

Dense retrieval uses a sentence-embedding encoder (BAAI/bge-m3) with L2-normalized vectors indexed in a FAISS inner-product (cosine) index. Sparse retrieval uses BM25 over lowercased whitespace tokens. The two ranked lists are fused with Reciprocal Rank Fusion (constant k = 60) [7], and the top K = 50 fused candidates form the retrieval set, matching the architecture's default. Recall@K on this fused set is measured and gated before any reranking comparison is drawn (Section VI-A).

### C. Relevance Reranking

S2 and S3 score each (query, candidate) pair with a cross-encoder reranker (BAAI/bge-reranker-v2-m3), applying its built-in sigmoid normalization and then re-normalizing (min-max) within the candidate set, since cross-encoder outputs are uncalibrated across queries.

### D. Faithfulness-Aware Reranking

S3 additionally computes Faith(c) as a weighted combination of four sub-signals, following [17]:

1. **Entailment** — the probability that a candidate passage entails the query/claim, from a zero-shot natural-language-inference model (MoritzLaurer/DeBERTa-v3-base-mnli-fever-anli). The entailment/contradiction label indices are read from the model's own label mapping at load time rather than assumed, to avoid a silent label-order mismatch.
2. **Self-containment** — whether a candidate can be understood without external context. This is implemented as a deterministic, rule-based proxy rather than a trained model: it penalizes sentence-initial anaphora and dangling cross-references (e.g., "as shown above," "the aforementioned") and rewards the presence of concrete numeric, temporal, unit, and named-entity markers.
3. **Corpus agreement** — one minus the maximum contradiction probability of a candidate against the other top-ranked candidates (from the same NLI model), capped to the top 10 co-candidates to bound the pairwise cost.
4. **Source reliability** — disabled for this corpus. The SciFact release provides title and abstract text only, with no publisher, effective-date, or version metadata, and the architecture specification explicitly instructs that missing metadata be excluded and the remaining weights renormalized rather than fabricated. This implementation follows that instruction: w4 is set to zero, w1/w2/w3 are renormalized over the remaining sum, and the omission is logged at runtime.

The four sub-signal weights, before this renormalization, follow the architecture's defaults (w1 = 0.45, w2 = 0.20, w3 = 0.20, w4 = 0.15).

### E. Score Fusion and Context Selection

Relevance and faithfulness scores are each min-max normalized within the candidate set and fused as S(c) = α·Rel(c) + β·Faith(c). An optional gate compares the normalized faithfulness score against a threshold τ_f: in "soft" mode, candidates below threshold are penalized by a fixed amount λ rather than removed; in "hard" mode, they are dropped from the candidate set. The top-N candidates by fused score are then selected for the generator using Maximal Marginal Relevance (to suppress near-duplicate passages), a "lost-in-the-middle"-aware reordering that places the highest-scoring passages at the two ends of the context window [9], and a whitespace-token budget to bound context length.

### F. Generation Pipeline

Because SciFact is a claim-verification benchmark rather than open-ended question answering, the generation task is framed as a grounded verdict: given the claim and the selected evidence passages (each with an identifier), the model must return exactly one of SUPPORTED, REFUTED, or NOT ENOUGH INFO, together with the evidence identifiers it relied on and a short rationale, and is instructed not to use outside knowledge. This prompt, and the decoding temperature (0.0), are held identical across all three systems.

### G. Design Rationale

The implementation deliberately separates two categories of code. Deterministic, dependency-light logic — rank fusion, information-retrieval metrics, score fusion and gating, MMR-based context selection, the self-containment heuristic, and the statistical tests used for evaluation — depends only on NumPy and SciPy and is covered by an offline unit-test suite that requires no network access or GPU. Model-dependent stages — the dense encoder, cross-encoder, NLI model, and generator — depend on the deterministic logic but are not themselves unit-testable offline. This separation lets the correctness of the ranking and evaluation arithmetic be verified independently of whether any particular model checkpoint is available, and it is the basis for the "not available" reporting used throughout this paper wherever a model-dependent measurement was not obtained.

---

## IV. Methodology

### A. Experimental Design

The three systems are compared under a controlled design: identical corpus, chunking (document-level, matching the benchmark's relevance judgments), retrieval index, retrieval parameters (K, RRF constant), generator, prompt, decoding parameters, and random seed. Only the reranking/faithfulness stage differs between S1, S2, and S3, which is what licenses attributing any observed difference to that stage rather than to a confound.

### B. Dataset

The dataset is SciFact [15], a scientific-claim-verification benchmark consisting of a corpus of 5,183 biomedical research abstracts and expert-written claims, each labeled SUPPORT, CONTRADICT, or (implicitly, via absence of evidence) not-enough-information, with rationale sentences marking the specific evidence within each abstract. SciFact was selected over alternative BEIR-benchmark datasets (e.g., FEVER, TREC-COVID, NFCorpus, HotpotQA, FiQA) because its claim/evidence structure maps directly onto the entailment sub-signal (the claim serves as the NLI hypothesis, the abstract as the premise), and because its SUPPORT/CONTRADICT labeling directly instantiates the "topically relevant but contradicted" failure mode that the faithfulness signal is designed to catch — a structural property that most of the alternative benchmarks, which provide only topical relevance judgments, do not offer. The official raw release (corpus and claim files) was used rather than a third-party mirror. The claims_train file was used as the development split (for the retrieval gate check and, in future work, for hyperparameter tuning); the claims_dev file was used as the test split from which the pilot evaluation sample was drawn. Exact split sizes are reported by the official release documentation and are not restated here to avoid transcribing a figure this paper did not independently re-verify; the pilot test sample size actually evaluated is stated exactly in Section VI.

### C. Baseline System (S1)

S1 performs hybrid retrieval and passes the top candidates directly to context selection in retrieval-fusion order, without any reranking or faithfulness stage. It establishes the floor against which S2 and S3 are compared and is also used to sanity-check the generation and evaluation harness.

### D. Relevance-Reranking System (S2)

S2 adds the cross-encoder relevance reranker (Section III-C) ahead of context selection, corresponding to the fused-score formula with β = 0. This is the primary comparison point for S3, since it isolates the marginal effect of the faithfulness signal from the marginal effect of adding any reranker at all.

### E. Faithfulness-Aware System (S3)

S3 adds faithfulness scoring and score fusion (Section III-D–III-E) after relevance reranking, using the architecture's default parameters: α = 0.7, β = 0.3, τ_f = 0.50, λ = 0.25, soft gate. These are the specification's documented starting values, not values tuned for this run; hyperparameter tuning on the development split was implemented as a separate procedure (Optuna search over α, the sub-signal weight simplex, τ_f, λ, and gate mode) but was **not executed** for the pilot reported here, and this is treated as a limitation (Section VII) rather than elided.

### F. Metrics

Retrieval/ranking quality is measured by Recall@K, Precision@N, Mean Reciprocal Rank, and nDCG@10. Answer quality is measured by answer correctness (verdict matches the gold label), faithfulness (the maximum entailment probability of the model's stated rationale by any selected context passage, averaged over answerable claims), and hallucination rate (the fraction of answerable claims where the answer cites an evidence identifier not present in the selected context, or where the rationale's entailment probability falls below 0.5). Abstention correctness is measured separately, over the subset of claims labeled NOT ENOUGH INFO, as the fraction where the system correctly abstains — since a system that never abstains cannot otherwise be distinguished from one that abstains only when correct to do so. Latency is measured per pipeline stage (retrieval, relevance reranking, faithfulness scoring, context selection, generation) using a monotonic clock, and reported as the 50th and 95th percentiles.

### G. Statistical Testing Methodology

For the S3-versus-S2 comparison on the claims common to both systems' test evaluation, hallucination rate (a binary per-claim outcome) is tested with McNemar's test on the discordant pairs; faithfulness, nDCG@10, and Precision@N (continuous per-claim outcomes) are tested with the paired Wilcoxon signed-rank test, and a paired bootstrap (10,000 resamples) is used to estimate a 95% confidence interval on the mean paired difference for each. The resulting family of four p-values is corrected for multiple comparisons using the Holm–Bonferroni step-down procedure at α = 0.05.

---

## V. Implementation Details

### A. Software Stack

The implementation is written in Python 3.10+. Core ranking, metric, and statistical logic uses only NumPy, SciPy, and pandas and has no model dependency. Model-dependent stages use sentence-transformers (dense encoder), FlagEmbedding (cross-encoder reranker), Hugging Face transformers (NLI model and, in one backend, the generator), rank_bm25 (sparse retrieval), and faiss-cpu (dense index). Configuration is stored in a single YAML file; hyperparameter search (not executed in this pilot) uses Optuna.

### B. Models Used

| Component | Model |
|---|---|
| Dense encoder | BAAI/bge-m3 |
| Cross-encoder reranker | BAAI/bge-reranker-v2-m3 |
| NLI / entailment model | MoritzLaurer/DeBERTa-v3-base-mnli-fever-anli |
| Generator (pilot run) | Qwen/Qwen2.5-3B-Instruct |

The generator used in the pilot run (Qwen2.5-3B-Instruct) differs from the 7-billion-parameter variant specified as the shipped configuration default; the smaller model was substituted to fit the memory constraints of the free-tier GPU used to execute the pilot. This is an implementation deviation from the originally configured default and is reported here rather than left implicit, since generator capacity can plausibly interact with both answer correctness and the faithfulness/hallucination metrics that depend on the generator's output.

### C. Retrieval Implementation

As described in Section III-B: L2-normalized BGE-M3 embeddings in a FAISS `IndexFlatIP` index; BM25Okapi over lowercased whitespace tokens; Reciprocal Rank Fusion with constant 60; top-50 fused candidates.

### D. Faithfulness Scoring Implementation

As described in Section III-D. The entailment and corpus-agreement sub-signals share one NLI model instance; corpus agreement is capped at 10 co-candidates per query to bound its pairwise cost. Self-containment is computed by a deterministic regular-expression heuristic (Section III-D.2) rather than a trained classifier. Source reliability (w4) is disabled for this corpus, with the remaining weights renormalized at run time and the omission logged.

### E. Ranking Pipeline

Score fusion, gating, MMR-based context selection, lost-in-the-middle-aware reordering, and token-budget enforcement are implemented in the dependency-light core module described in Section III-G and are covered by nine automated unit tests on synthetic fixtures, all passing. These tests verify the correctness of the ranking and evaluation arithmetic; they are not experimental results and are not a substitute for the SciFact evaluation reported in Section VI.

### F. Configuration Parameters

Table I lists the configuration values used for the pilot run reported in Section VI.

**TABLE I. Pilot Run Configuration**

| Parameter | Value | Tunable per [17] | Tuned in this pilot? |
|---|---|---|---|
| K (candidates) | 50 | Yes | No — default used |
| RRF constant | 60 | — | — |
| Retrieval gate (recall@K) | 0.85 | No (fixed) | N/A |
| α (relevance weight) | 0.70 | Yes | No — default used |
| β (faithfulness weight) | 0.30 | Yes | No — default used |
| τ_f (gate threshold) | 0.50 | Yes | No — default used |
| λ (soft-gate penalty) | 0.25 | Yes | No — default used |
| Gate mode | soft | Yes | No — default used |
| w1 (entailment) | 0.45 | Yes | No — default used |
| w2 (self-containment) | 0.20 | Yes | No — default used |
| w3 (corpus agreement) | 0.20 | Yes | No — default used |
| w4 (source reliability) | 0 (disabled) | Yes | N/A — unavailable on this corpus |
| N (context passages) | 5 | No (fixed across systems) | — |
| MMR λ | 0.50 | — | — |
| Token budget | 1,200 | — | — |
| Generation temperature | 0.0 | No (fixed) | — |
| Random seed | 42 | No (fixed) | — |

### G. Engineering Considerations

The three systems share one execution path parameterized by a system flag, so that the reranking/faithfulness stage is the only code that differs between configurations; this is intended to prevent unintended divergence in retrieval, context assembly, or generation logic between systems. Latency is measured independently for each pipeline stage rather than only end-to-end, so that the cost attributable specifically to faithfulness scoring can be isolated (Section VI-D). A rule-based error taxonomy (retrieval miss, ranking error, faithfulness-scoring/fusion error, generation error, and others) is computed automatically for each failing query by checking, in order, whether the gold evidence document reached the candidate set, then the final context window, so that failures can be attributed to a pipeline stage without manual annotation.

---

## VI. Results and Discussion

**This section reports a pilot evaluation, not a fully powered final evaluation.** The results below were obtained from 20 test-split claims (`n = 20`), with the ablation study and hyperparameter tuning **not executed** for this run. Numbers are reported exactly as produced by the evaluation harness; no value in this section has been rounded beyond what is shown, adjusted, or estimated.

### A. Retrieval Gate

Recall@50, measured over the full development split (not the 20-claim pilot subset), was **0.990**, exceeding the architecture's 0.85 gate threshold. Reranking-stage comparisons are therefore made on a retrieval foundation the architecture considers sufficient — the reranker is not being asked to recover evidence that first-stage retrieval failed to return.

### B. Pilot Metrics

**TABLE II. Pilot Evaluation Metrics (n = 20 test claims)**

| Metric | S1 | S2 | S3 |
|---|---|---|---|
| nDCG@10 | 0.866 | 0.972 | 0.956 |
| Precision@N | 0.185 | 0.215 | 0.215 |
| Answer correctness | 0.450 | 0.450 | 0.400 |
| Faithfulness | 0.634 | 0.679 | 0.779 |
| Hallucination rate | 0.385 | 0.308 | 0.231 |
| Abstention correctness (n = 7 unanswerable) | 0.143 | 0.143 | 0.000 |

Faithfulness increases and hallucination rate decreases monotonically from S1 through S3, which is the direction the research hypothesis predicts. Answer correctness and nDCG@10 do not follow the same monotonic pattern: nDCG@10 is highest for S2, and answer correctness is slightly lower for S3 than for S1/S2.

### C. Statistical Significance

**TABLE III. Paired Tests, S3 vs. S2 (n = 20 common claims), Holm–Bonferroni Corrected**

| Test | Metric | p (raw) | p (adjusted) | Reject H0 at α = 0.05? |
|---|---|---|---|---|
| Wilcoxon signed-rank | Faithfulness | 0.027 | 0.108 | No |
| Wilcoxon signed-rank | nDCG@10 | 0.317 | 0.952 | No |
| Wilcoxon signed-rank | Precision@N | 1.000 | 1.000 | No |
| McNemar | Hallucination rate | 1.000 | 1.000 | No |

No comparison survives correction at this sample size. The McNemar test on hallucination rate is based on only 3 discordant pairs out of 20 (S3 worse on 1 claim, better on 2), which is too few to distinguish a real effect from sampling noise. The uncorrected faithfulness Wilcoxon p-value (0.027) would be significant on its own but does not survive correction for the family of four tests.

**TABLE IV. Bootstrap Effect Sizes (S3 − S2, uncorrected, reported for transparency)**

| Metric | Mean difference | 95% CI |
|---|---|---|
| Faithfulness | +0.226 | [0.067, 0.388] |
| nDCG@10 | −0.010 | [−0.030, 0.000] |
| Precision@N | 0.000 | [0.000, 0.000] |

The faithfulness confidence interval excludes zero, which at this sample size should be read as an estimate consistent with an effect, not as confirmatory evidence of one; a properly powered evaluation on the full test split is required before this can be treated as a finding.

### D. Latency

**TABLE V. Per-Stage Latency (seconds), p50 / p95**

| Stage | S1 | S2 | S3 |
|---|---|---|---|
| Retrieval | 0.044 / 0.066 | 0.047 / 0.063 | 0.046 / 0.067 |
| Relevance reranking | — | 2.539 / 3.103 | 2.588 / 2.654 |
| Faithfulness scoring | — | — | 12.003 / 12.489 |
| Context selection | 0.001 / 0.002 | 0.001 / 0.002 | 0.001 / 0.002 |
| Generation | 9.303 / 12.984 | 10.892 / 12.950 | 11.304 / 12.818 |

The faithfulness-scoring stage adds approximately 12 seconds of p50 latency per query on top of the relevance-reranking pipeline, roughly doubling total per-query latency relative to S2 (approximately 13.5 s for S2 versus 25.9 s for S3, summing the measured stages). This is consistent with the architecture specification's own stated expectation that the entailment sub-signal, requiring an additional model pass over the candidate set, would dominate the added cost. Any groundedness or hallucination-rate benefit attributable to S3 in a fully powered evaluation would need to be weighed explicitly against this latency cost, which the research question treats as a first-class outcome rather than an afterthought.

### E. Abstention Behavior

Of the 20 pilot claims, 7 were labeled NOT ENOUGH INFO. S1 and S2 each abstained correctly on 1 of these 7 (0.143); S3 abstained correctly on 0 of 7 (0.000). This is the single most notable pattern in the pilot results and is reported here as an observation, not a conclusion: with only 7 unanswerable claims in the sample, this could plausibly be sampling noise, and it should not be interpreted as evidence that faithfulness-aware reranking suppresses abstention in general. It is, however, a specific, falsifiable pattern to check against the full test split, and a plausible mechanism is worth stating for that future check: if the faithfulness signal systematically favors passages that read as confident and well-supported, it could make the generator less likely to select NOT ENOUGH INFO even on claims where that is the correct verdict. Whether this mechanism actually operates, or whether the pattern disappears at scale, cannot be determined from this pilot.

### F. Error Distribution

**TABLE VI. Error Bucket Counts (Pilot, n = 20)**

| Bucket | S1 | S2 | S3 |
|---|---|---|---|
| Retrieval miss | 0 | 0 | 0 |
| Ranking error | 1 | 0 | 0 |
| Fusion error | 0 | 0 | 0 |
| Generation error | 13 | 13 | 15 |

No retrieval misses occurred in the pilot sample, consistent with the high measured recall@K gate. The dominant error bucket for all three systems is generation error (a case in which the gold evidence reached the final context but the generated verdict was still incorrect, or the claim was unanswerable and the system did not abstain correctly), which increases slightly for S3 relative to S1 and S2 in this sample — consistent with, though not sufficient on its own to explain, the lower answer-correctness and abstention-correctness figures observed for S3 above.

### G. Ablation Study

**Not conducted.** The ablation grid specified by the architecture — removing each faithfulness sub-signal in turn, comparing the soft, hard, and disabled gate modes, and sweeping α across its range — was implemented in the evaluation harness but was not executed for this pilot (the run used a flag that explicitly skips it). No ablation results are reported. This is a limitation of the present work, not an omission of available data, and is listed again in Section VII.

---

## VII. Threats to Validity

### A. Internal Validity

The α, β, τ_f, λ, and sub-signal-weight values used for S3 are the architecture's documented starting values, not values tuned on the development split as the protocol specifies. The pilot therefore evaluates the architecture's default configuration, not its best achievable configuration, and any comparison to a tuned S2 baseline (which was also not tuned, but has fewer free parameters) should be read with that asymmetry in mind. Separately, the generator used (Qwen2.5-3B-Instruct) differs from the 7-billion-parameter default in the shipped configuration, substituted for GPU memory reasons; this could interact with the measured faithfulness and hallucination metrics in ways that would not hold for the originally specified model.

### B. External Validity

The pilot covers a single domain (biomedical claim verification), a single corpus (SciFact), and 20 of the labeled test claims. No claim is made, or should be inferred, about performance on the full test split, on other domains, or on corpora with genuine document versioning — a failure mode (superseded evidence) that SciFact's un-versioned corpus cannot exercise, and which the architecture specification identifies as a distinct case from the contradicted-evidence case SciFact does support.

### C. Construct Validity

Faithfulness is operationalized here as the entailment probability of a single generated rationale sentence by the best-matching selected passage — a proxy for "evidential adequacy," consistent with the architecture's own framing that answer faithfulness cannot be measured before an answer exists, but not a validated measure of full answer faithfulness in the sense of verifying every claim in a longer generated response. The architecture's more accurate two-pass draft-then-verify variant, which decomposes a draft answer into individual claims before scoring, was not implemented. The self-containment sub-signal is a hand-built rule-based heuristic and has not been validated against human judgments of self-containment; the architecture's own stated primary methodological risk — that general-purpose NLI models lose accuracy on technical registers — has likewise not yet been checked against SciFact's human-labeled rationales in this work.

### D. Sample-Size Limitations

Twenty claims, evaluated against a family of four corrected significance tests, is substantially underpowered. None of the four tests reject the null hypothesis after Holm–Bonferroni correction. The bootstrap confidence interval on the faithfulness difference excludes zero, but at n = 20 this should be treated as a preliminary estimate, not as evidence of a real effect.

### E. Pilot Study Limitations

In addition to the above: the ablation study was not executed; hyperparameter tuning was not executed; the source-reliability sub-signal could not be evaluated on this corpus at all, for any configuration, due to missing metadata; and the abstention-correctness result (Section VI-E) is based on only 7 unanswerable claims.

---

## VIII. Conclusion and Future Work

### A. Summary of Findings

This work implemented the faithfulness-aware reranking architecture specified in [17] as a controlled, three-system pipeline (S1/S2/S3) on the SciFact claim-verification benchmark, validated that the retrieval stage clears the architecture's recall@K gate, and ran a pilot evaluation on 20 test claims. The pilot shows faithfulness increasing and hallucination rate decreasing monotonically from S1 to S3, consistent with the direction of the paper's research hypothesis, but none of the paired significance tests survive correction for multiple comparisons at this sample size, and the faithfulness-scoring stage roughly doubles measured per-query latency relative to relevance-only reranking. A drop in abstention correctness for S3, observed on a small unanswerable-claim subsample, is reported as an open question rather than a finding.

### B. Practical Contributions

The implementation separates deterministic, unit-testable ranking and evaluation logic from model-dependent stages, which allows the correctness of the ranking arithmetic to be verified independently of model availability. It resolves the architecture's source-reliability sub-signal on a corpus that cannot support it by disabling and renormalizing rather than fabricating metadata, following the architecture's own stated rule for this situation. It also provides a working, automated error taxonomy and a statistical-testing harness (paired Wilcoxon, McNemar, bootstrap, Holm–Bonferroni correction) ready to apply to a full-scale run.

### C. Limitations

As detailed in Section VII: untuned hyperparameters, no ablation study, a single small pilot sample, a single domain and corpus, a proxy (single-rationale-entailment) construct for faithfulness rather than the architecture's more complete two-pass variant, and an unvalidated rule-based self-containment heuristic.

### D. Future Work

The immediate next step is to execute the full evaluation without the sampling and ablation-skipping flags used for this pilot: running the development-split hyperparameter search (already implemented) before evaluating on the complete labeled test split, and running the ablation grid (sub-signal removal, gate-mode comparison, α sweep) that this pilot did not execute. Beyond that, validating the NLI entailment signal and the self-containment heuristic against SciFact's human-labeled rationales, as the architecture's stated methodological risk requires, would establish whether the faithfulness sub-signals are measuring what they are intended to measure on this corpus. Implementing the two-pass draft-then-verify faithfulness variant would test whether a closer approximation to answer faithfulness changes the observed pattern. Finally, extending the evaluation to a second, contrasting domain corpus with genuine document versioning would test the temporal-supersession failure mode that SciFact's corpus cannot exercise, and would bear directly on the external validity of any conclusion drawn from this architecture.

---

## References

[1] P. Lewis et al., "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks," 2020.

[2] Y. Gao et al., "Retrieval-Augmented Generation for Large Language Models: A Survey," 2023.

[3] V. Karpukhin et al., "Dense Passage Retrieval for Open-Domain Question Answering," 2020.

[4] R. Nogueira and K. Cho, "Passage Re-ranking with BERT," 2019.

[5] N. Reimers and I. Gurevych, "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks," 2019.

[6] S. Robertson and H. Zaragoza, "The Probabilistic Relevance Framework: BM25 and Beyond," 2009.

[7] G. V. Cormack, C. L. A. Clarke, and S. Büttcher, "Reciprocal Rank Fusion Outperforms Condorcet and Individual Rank Learning Methods," in *Proc. ACM SIGIR*, 2009.

[8] N. Thakur, N. Reimers, A. Rücklé, A. Srivastava, and I. Gurevych, "BEIR: A Heterogeneous Benchmark for Zero-shot Evaluation of Information Retrieval Models," 2021.

[9] N. F. Liu et al., "Lost in the Middle: How Language Models Use Long Contexts," 2023.

[10] Z. Ji et al., "Survey of Hallucination in Natural Language Generation," 2023.

[11] O. Honovich et al., "TRUE: Re-evaluating Factual Consistency Evaluation," 2022.

[12] Y. Zha et al., "AlignScore: Evaluating Factual Consistency with a Unified Alignment Function," 2023.

[13] L. Tang et al., "MiniCheck: Efficient Fact-Checking of LLMs on Grounding Documents," 2024.

[14] S. Es, J. James, L. Espinosa-Anke, and S. Schockaert, "RAGAS: Automated Evaluation of Retrieval Augmented Generation," 2023.

[15] D. Wadden, S. Lin, K. Lo, L. L. Wang, M. van Zuylen, A. Cohan, and H. Hajishirzi, "Fact or Fiction: Verifying Scientific Claims," in *Proc. EMNLP*, 2020, pp. 7534–7550. DOI: 10.18653/v1/2020.emnlp-main.609.

[16] D. Wadden, K. Lo, B. Kuehl, A. Cohan, I. Beltagy, L. L. Wang, and H. Hajishirzi, "SciFact-Open: Towards Open-Domain Scientific Claim Verification," in *Findings of EMNLP*, 2022, pp. 4719–4734.

[17] M. K. Khan, "Faithfulness-Aware Reranking for Domain-Specific Retrieval-Augmented Generation: Technical Architecture and Implementation Design," Jamia Millia Islamia, Technical Report v1.0 (draft), 2026. Unpublished manuscript.

[REF-18] BAAI, "BAAI/bge-m3" (model card), Hugging Face. Full formal citation to be verified and completed before submission.

[REF-19] BAAI, "BAAI/bge-reranker-v2-m3" (model card), Hugging Face. Full formal citation to be verified and completed before submission.

[REF-20] M. Laurer et al., "MoritzLaurer/DeBERTa-v3-base-mnli-fever-anli" (model card), Hugging Face. Full formal citation to be verified and completed before submission.

[REF-21] Qwen Team, technical report for the Qwen2.5 model family. Not independently verified within this project; confirm exact citation before submission.

> **Note on references [1]–[14], [16]:** these entries were provided as an initial bibliography in the source architecture document [17] without venue, page, or DOI information for most entries beyond what is listed above. The architecture document itself instructs that these be "verified" and completed to the target venue's citation style "before submission." That verification was not independently performed as part of this project and must be completed — venue names, page numbers, and DOIs added or corrected — before this manuscript is submitted anywhere.
